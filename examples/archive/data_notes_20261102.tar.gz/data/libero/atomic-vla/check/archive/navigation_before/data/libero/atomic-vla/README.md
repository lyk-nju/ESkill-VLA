# AtomicVLA：LIBERO 事件标注

**2026-10-31：用户抽看原版视频后认可数据大体可用，确定作为后续 LIBERO 主来源。** 主体采用作者的事件／技能标签及其指定的基础 RGB、状态与动作记录，并应用用户确认的边界和技能修正。

**2026-11-01 最新产物：[全量逐帧标签与人工验收入口](check/test/full_frame_v1/index.html)**。40 个任务、1,693 条、273,465 帧的主相机夹爪／操作物体完整屏内区域已生成，546,930 组 mask／bbox 与保存回读检查通过，3,873 个 Event 终点对象框可读取。已从落盘标签渲染 55 条完整视频，覆盖全部 40 任务、全部 12 条助手实例补充及各套件最大对齐偏差样本；[验收说明](check/test/full_frame_v1/README.md) · [人工表](check/test/full_frame_v1/manual_review.csv) · [核验汇总](check/test/full_frame_v1/verification.json)。用户验收 pending，740 条原状态对齐警示保留。

55 条现已整理成 [一条完整验收视频（20 分 13.7 秒）](check/test/video/full_frame_v1/atomicvla_55_full_frame_review.mp4)，支持 [按章节跳转](check/test/full_frame_v1/merged55/index.html)。

2026-11-01 后续：用户已批准共享边界帧归后一个 Event。[来源适配器](../../../scripts/preprocess/libero/atomic_vla/source.py) 默认使用该规则，并同步更新前一 Event 的终点；全量 1,693 条的 45 处共享边界已修正，273,465 帧均有唯一事件归属。[边界与原标签核验](check/test/annotation_review/README.md) 保存原始边界及逐项变更。

用户观看冲突视频后确认 33 个事件属于 Push：压住操作物体，利用摩擦力沿支撑面平移。适配器已将这些事件的派生技能由 Pick 改为 Push，原标签保留；当前技能数量为 Pick 1,801／Place 1,800／Open 79／Close 69／Turn 91／Push 33。[最新规范化事件与视频](check/test/annotation_review/push_reviewed/README.md) · [用户确认记录](check/test/annotation_review/skill_review.json)。035／046 在新输出中为 Push，下面旧 v1／v2 视频仍显示修改前标签。

**通用规则统计（手工补充前）：[1,693 条规则报告与 10 条完整核验视频](check/test/all_rules_v1/README.md)**。3,839／3,873 个 Event、1,681／1,693 条全部事件有唯一实例候选；当时 12 条有 34 个绑定缺口，另有 740 条触发官方状态与 RLDS 末端偏差警示。候选覆盖率不等于正确率；[查看该批次](check/test/all_rules_v1/index.html)。

用户随后授权手工处理这 12 条。助手通过原始主相机事件图、原生实例锚点和连续运动／接触记录已补 34 个实例，见 [人工补充记录、全量合并标签与 12 条视频](check/test/manual_binding12/README.md)。合并标签中 1,693 条的实例字段已补齐；自动统计仍是上面的 1,681 条，不把助手标注计入规则覆盖率。用户对本轮标注及位置对齐的验收仍待完成。

**预保存格式与接口**：公共 [fields.py](../../../scripts/preprocess/fields.py)／[eskill_dataset.py](../../../src/openpi/policies/eskill_dataset.py) 使用每条轨迹 JSON＋NPZ；[来源导出器](../../../scripts/preprocess/libero/atomic_vla/export.py)接收逐帧原生区域和最新合并实例标签。[batch.py](../../../scripts/preprocess/libero/atomic_vla/batch.py) 已完成全量生成、保存回读和验收视频；标签在数据盘，通过 [episodes/](check/test/full_frame_v1/episodes/) 访问。此前的 [3 条／683 帧接口试点](check/test/saved_format/README.md) 保留，最终视频均读取落盘标签。

2026-11-01 新增 [官方 LIBERO-40 状态对齐实验](../libero-40/README.md)：同一 100 条均在官方 HDF5 找到唯一动作对应，包括此前缺场景的 011／044／067。官方状态生成的区域和对照另存该目录，保留与原 RGB 的偏差及人工待核验状态；下面 v1／v2 数字仍指各自历史批次。

历史 v2 人工核验：**[26 条新增／变化轨迹视频](check/test/binding_v2/index.html) · [v2 结果与当时剩余问题](check/test/binding_v2/README.md)**。同一固定 100 条的唯一绑定由 192 增至 236 / 238 个 Event，原 192 个对象／部件未改变；当时 99 条全部事件有候选，95 条区域完整且每帧事件唯一。这些数字是该批次的覆盖率，不是正确率。

v1 基线保留：[100 条合并视频（27 分 46.2 秒）](check/test/video/atomicvla_100_native_rule_v1.mp4) · [章节跳转](check/test/review100_v1/index.html) · [说明与核对表](check/test/review100_v1/README.md)。用户查看 004／008／048 后反馈未见明显问题，见 [三条反馈记录](check/test/alignment_review/README.md)；不据此将全批标为验收通过。

当前处理方向：夹爪采用源关节恢复＋原生相机渲染，物体采用动作序列匹配的完整场景状态，分别从独立渲染的 mask 导出 bbox；Event 终点读取同一对象区域。此前 v1／v2 的 100 条中 97 条匹配到场景，011／044／067 的物体框在这些历史产物中仍缺失；v2 另有 015 后两个摩卡壶 Event 因状态对齐证据不足保留歧义。014 源事件重叠、035／046 的 Push／Pick 冲突分别记录。既有 Qwen3-VL＋SAM3 定位／跟踪结果保留作参考，源技能不自动修改。

用户随后统一区域定义：夹爪与物体都取忽略外部遮挡的完整屏内框，当前和 Event 终点一致。新增 [完整区域三帧对照](check/test/native_object_full/README.md)；此前物体可见框保留作参考，不视作满足新定义。

Event → 实例／部件规则初版见 [核对表](check/test/instance_binding/README.md)。[bind_instances.py](../../../scripts/preprocess/libero/atomic_vla/bind_instances.py) 读取原事件与对应 BDDL，[binding_rules.json](../../../scripts/preprocess/libero/atomic_vla/binding_rules.json) 只维护类别别名、初始区域语义及可操作部件；不按事件序号或实例编号指派。初版十条 24 个 Event 的规则候选、实际几何、运动证据和人工状态分别记录，当时只有 case01 有匹配完整场景状态；该历史报告不与本轮 100 条混计。三帧接入检查见 [native_preview](check/test/instance_binding/native_preview/README.md)，均为待人工核验的测试结果。

早期模型补框测试见 [check/test](check/test/README.md)，入口为 [grounding.py](../../../scripts/preprocess/libero/atomic_vla/grounding.py)，来源读取为 [source.py](../../../scripts/preprocess/libero/atomic_vla/source.py)。该历史测试中间段保留闭区间，末段 end=N 作为右边界，原始 start/end 另行保留。现有共享模型 CLI 的 `--dataset libero` 仍读取 GuidedVLA；AtomicVLA 当前使用来源专用入口。用户选定来源不自动改写逐条人工表或标记补标质量通过。

首轮测试已输出 [10 条主相机补框视频](check/test/index.html)，共 1,575 帧；当前仍有夹爪框落到关节／画面边缘、对象选错及缺失，全部待审核，不能直接作为训练标签。

此前模型测试的三维布局见 [十条历史视频](check/test/render_3d_index.html)／[预览图](check/test/render_3d_preview.png)，先前布局仍在 [旧入口](check/test/render_index.html)。输入字段与来源适配见 [统一渲染器说明](../README.md#共用人工核验渲染器)；本轮优先核验上方 100 条原生区域视频。

来源：[官方仓库](https://github.com/zhanglk9/AtomicVLA)／[作者指定的基础 RLDS](https://huggingface.co/datasets/openvla/modified_libero_rlds)／[事件 JSON](https://github.com/zhanglk9/AtomicVLA/blob/33d2f98574a52838b9db34b334bd5cc6cbe57f50/data_split_json/libero_lerobot.json)。这指 CVPR 2026 的 AtomicVLA，不是同名的其他个人项目。

基础数据版本 `6ce6aaaaabdbe590b1eef5cd29c0d33f14a08551`；代码／标注版本 `33d2f98574a52838b9db34b334bd5cc6cbe57f50`。作者发布 1,693 条 episode 的 JSON，以整数 episode ID 关联基础 RGB／动作数据；这不是已打包成统一容器的新 RGB 数据集。事件字段包括 `start_frame/end_frame/primary_action_verb/chain_of_thought`，范围和关联仍需核验。

本轮抽取基础轨迹，检查 JSON 与其任务、帧数和读取顺序的对应。80 条候选的任务和帧数均匹配；原版 10 条视频已完成，逐项人工表尚未填写。核验视频见 [raw](check/raw/README.md)，字段表见 [field_check.md](check/field_check.md)，脚本见 [check_raw.py](../../../scripts/preprocess/libero/check_raw.py)。

## 实例绑定的通用性约定

2026-11-01 的具体优化顺序、函数职责和验证条件见 [v2 设计依据](binding_v2_plan.md)。实现入口为 [binding_v2.py](../../../scripts/preprocess/libero/atomic_vla/binding_v2.py)，实际接触／运动证据为 [binding_motion.py](../../../scripts/preprocess/libero/atomic_vla/binding_motion.py)，固定 100 条结果见 [核验记录](check/test/binding_v2/README.md)。

2026-10-31 用户明确要求规则尽可能通用。以下约束已用于 v2 实现与机制检查；当前 v1 及其 100 条结果保持原样，未开展未见真实任务的泛化评估。

| 环节 | 通用做法 |
| --- | --- |
| 对象描述 | 解析类别、显式属性、空间限定和部件；泛称在场景中收集候选，保留颜色／位置等约束，不能遇到未知词就删掉 |
| 场景查询 | 使用实体、区域所属实体、部件所属实体和初始／当前关系；`on stove` 通过区域归属查询，避免把参照实体与区域名直接比较 |
| 来源适配 | 类别别名、具有关节的部件与实际几何名称在配置／适配函数中描述；规则核心不出现轨迹编号、任务白名单或固定实例答案 |
| 上下文 | 根据明确且一致的任务描述补全省略的部件；同臂 Pick→Hold／Place 在连续持物证据下继承身份，释放后清除，不按 Event 顺序分配同类对象 |
| 多候选 | 综合接触、持续运动及夹爪—物体关系消歧，记录证据来源与状态对齐质量；证据不足保留歧义，不能默认第一个、最近或移动最多的候选 |
| 技能审核 | 对象提取与源技能一致性分别记录；可确认 plate 的身份，同时保留 Push 描述与 Pick 标签的冲突，不静默改源技能 |

`region_relations` 的少量完整短语查表是 v1 的局限。v2 已改为“关系解析＋场景查询”；从命名区域读取语义仍属于 LIBERO 适配，不能宣称适用于任意模拟器命名。无可解释的语义时保留未解析状态。

代码保持简洁，优先复用现有绑定函数、来源读取和几何解析入口；暂不因追求通用性新增复杂框架。具体实例／部件由运行时场景确定，BDDL goal 或 `obj_of_interest` 不作为直接选取操作对象的答案。

验证分两部分：现有 100 条固定用于回归；另选未参与规则制定的任务或对象／关系组合检验泛化。针对规则机制检查候选顺序重排、实例重命名、同类干扰物、未知属性与上下文冲突等变化，不能只验证本批成功案例，也不能把已看过的轨迹重新划分后称为未见任务。

## 作者公开的事件标注管线

2026-10-31 已静态核对同版本 [InternVideo2/](https://github.com/zhanglk9/AtomicVLA/tree/33d2f98574a52838b9db34b334bd5cc6cbe57f50/InternVideo2)：`main.py`／`batch_annotator.py` 批量读取轨迹，`action_segmenter.py` 根据夹爪动作变化及末端平移／旋转规则确定候选边界；`video_processor.py` 用 InternVideo2.5 Chat 8B 查看整段视频生成 Task Chain，再按顺序给候选区间分配步骤与技能；`training_export.py` 检查对应关系并导出 `train_annotations.json`，另存排除与失败记录。

输入为支持的 LeRobot Parquet 布局：每条 episode 一个文件，含 `image/actions/state/task_index`，任务表为 `meta/tasks.jsonl`。本项目当前抽样缓存是 RLDS，复用该代码需先适配读取；本轮未安装或运行作者标注模型，也未证明公开流程能逐条重现既有发布 JSON。

端点源码线索：`action_segmenter.py` 将末段 end 设为 `total_len`，中间段按前段 end+1 衔接；导出器允许 end 等于源帧数，而视频裁剪使用 `range(start,end)`。需在项目适配中明确末帧索引，不能将所有 end 无条件当作可读取图像编号。
